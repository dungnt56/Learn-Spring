package com.sapo.edu.demo;

public interface Printer {
    void printCustoner(Customer customer);

    void printMessage(String message);
}
